package scannerdemo1;

import java.util.Scanner;

public class Power {

	public static void main(String[] args) {
		Scanner Sc=new Scanner(System.in);
		System.out.println("Enter base");
		int base=Sc.nextInt();
		System.out.println("Enter power");
		int power=Sc.nextInt();
		int ans=1;
		for(int i=1;i<=power;i++)
		{
			ans=ans*base;
			
		}
		System.out.println(ans);
		
		

	}

}
